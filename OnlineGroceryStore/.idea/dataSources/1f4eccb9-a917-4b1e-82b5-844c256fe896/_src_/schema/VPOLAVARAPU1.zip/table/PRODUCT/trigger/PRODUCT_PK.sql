create trigger PRODUCT_PK
	before insert
	on PRODUCT
	for each row
BEGIN
  SELECT PRODUCT_SEQ.NEXTVAL
  INTO   :new.PRODUCT_ID
  FROM   dual;
END;