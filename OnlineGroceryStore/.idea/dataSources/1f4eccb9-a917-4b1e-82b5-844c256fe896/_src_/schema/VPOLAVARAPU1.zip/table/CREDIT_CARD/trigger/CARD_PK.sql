create trigger CARD_PK
	before insert
	on CREDIT_CARD
	for each row
BEGIN
  SELECT CARD_SEQ.NEXTVAL
  INTO   :new.CARD_ID
  FROM   dual;
END;