create trigger WHOUSE_PK
	before insert
	on WAREHOUSE
	for each row
BEGIN
  SELECT WHOUSE_SEQ.NEXTVAL
  INTO   :NEW.WAREHOUSE_ID
  FROM   DUAL;
END;