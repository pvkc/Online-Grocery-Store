create trigger STAFF_PK
	before insert
	on STAFF
	for each row
BEGIN
  SELECT TO_CHAR(SYSDATE, 'J') || STAFF_SEQ.NEXTVAL
  INTO   :new.STAFF_ID
  FROM   dual;
END;