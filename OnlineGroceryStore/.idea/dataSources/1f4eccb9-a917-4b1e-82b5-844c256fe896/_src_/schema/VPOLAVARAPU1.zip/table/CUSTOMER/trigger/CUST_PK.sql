create trigger CUST_PK
	before insert
	on CUSTOMER
	for each row
BEGIN
  SELECT cust_seq.NEXTVAL
  INTO   :new.CUSTOMER_ID
  FROM   dual;
END;