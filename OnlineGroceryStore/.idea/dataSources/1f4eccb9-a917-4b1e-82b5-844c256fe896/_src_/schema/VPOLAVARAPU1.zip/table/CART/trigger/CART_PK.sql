create trigger CART_PK
	before insert
	on CART
	for each row
BEGIN
  SELECT CART_SEQ.NEXTVAL
  INTO   :NEW.CART_ID
  FROM   DUAL;
END;