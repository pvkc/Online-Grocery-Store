create trigger ADDR_PK
	before insert
	on ADDRESS
	for each row
BEGIN
  SELECT addr_seq.NEXTVAL
  INTO   :new.ADDR_ID
  FROM   dual;
END;